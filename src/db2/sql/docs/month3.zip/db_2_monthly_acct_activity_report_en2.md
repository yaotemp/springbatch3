# DB2 Monthly Accounting Activity Report (English Version)

## 📘 Table of Contents

1. [DB2 Monthly SQL Activity Report (Accounting)](#1-db2-monthly-sql-activity-report-accounting)
2. [DB2 Monthly DML Distribution Report (Accounting)](#2-db2-monthly-dml-distribution-report-accounting)
3. [DB2 Monthly Transaction Summary Report (Accounting)](#3-db2-monthly-transaction-summary-report-accounting)
4. [DB2 Monthly CPU Performance Report](#4-db2-monthly-cpu-performance-report)
5. [DB2 Monthly Wait Time Analysis Report](#5-db2-monthly-wait-time-analysis-report)
6. [DB2 Monthly Lock Contention Report (Accounting)](#6-db2-monthly-lock-contention-report-accounting)
7. [DB2 Monthly Row Operations Report](#7-db2-monthly-row-operations-report)
8. [DB2 Month-over-Month Activity Change Detection Report](#8-db2-month-over-month-activity-change-detection-report)
9. [DB2 Peak Activity Month Identification Report](#9-db2-peak-activity-month-identification-report)
10. [DB2 Monthly zIIP Offload Analysis Report](#10-db2-monthly-ziip-offload-analysis-report)

---

## 1. DB2 Monthly SQL Activity Report (Accounting)

### Description

This report provides a monthly overview of all SQL activity from DB2 accounting data, including counts of SELECT, INSERT, UPDATE, DELETE, and MERGE operations, average execution efficiency, and lock conflict rates. It is designed for monthly performance trend analysis at the thread/plan level.

### SQL Code

```sql
-- =============================================
-- DB2 Monthly SQL Activity Report (Accounting)
-- Author: Jay Yao
-- Purpose: Summarize SQL execution activity by month for trend analysis
-- Data Source: DTRBDR55.DB2PMFACCT_GENERAL
-- =============================================

SELECT
    SUBSYSTEM_ID,
    YEAR(TIMESTAMP) AS REPORT_YEAR,                -- Aggregation year
    MONTH(TIMESTAMP) AS REPORT_MONTH,              -- Aggregation month
    COUNT(*) AS RECORD_COUNT,                      -- Number of accounting records per month

    SUM(SELECT) AS TOTAL_SELECTS,                  -- Total SELECT statements executed
    SUM(INSERT) AS TOTAL_INSERTS,                  -- Total INSERT statements executed
    SUM(UPDATE) AS TOTAL_UPDATES,                  -- Total UPDATE statements executed
    SUM(DELETE) AS TOTAL_DELETES,                  -- Total DELETE statements executed
    SUM(MERGE) AS TOTAL_MERGES,                    -- Total MERGE statements executed

    SUM(SELECT + INSERT + UPDATE + DELETE + MERGE) AS TOTAL_DML,  -- Total DML operations

    -- Daily average DML operations
    ROUND(SUM(SELECT + INSERT + UPDATE + DELETE + MERGE) * 1.0 / 
          COUNT(DISTINCT DATE(TIMESTAMP)), 2) AS AVG_DAILY_DML,

    CASE WHEN SUM(SELECT + INSERT + UPDATE + DELETE + MERGE) > 0 THEN
         ROUND(SUM(COMMIT) * 1.0 /
               SUM(SELECT + INSERT + UPDATE + DELETE + MERGE), 4)
    ELSE NULL END AS COMMIT_PER_DML,               -- Average commits per DML

    CASE WHEN SUM(SELECT) > 0 THEN
         ROUND(SUM(DELETE) * 100.0 / SUM(SELECT), 2)
    ELSE NULL END AS DELETE_TO_SELECT_RATIO,       -- Ratio of DELETE to SELECT (%)

    CASE WHEN SUM(SELECT + INSERT + UPDATE + DELETE + MERGE) > 0 THEN
         ROUND(SUM(DEADLOCK + TIMEOUT) * 100.0 /
               SUM(SELECT + INSERT + UPDATE + DELETE + MERGE), 4)
    ELSE NULL END AS LOCK_CONFLICT_RATE,           -- % of deadlock or timeout

    -- Peak day identification
    MAX(SELECT + INSERT + UPDATE + DELETE + MERGE) AS PEAK_DML_COUNT  -- Peak DML in single record

FROM DTRBDR55.DB2PMFACCT_GENERAL
WHERE 1=1
  AND SUBSYSTEM_ID = 'PDBC'
  AND TIMESTAMP BETWEEN '2025-01-01-00.00.00' AND '2025-12-31-23.59.59'

GROUP BY SUBSYSTEM_ID, YEAR(TIMESTAMP), MONTH(TIMESTAMP)
ORDER BY YEAR(TIMESTAMP) DESC, MONTH(TIMESTAMP) DESC;
```

### Field Descriptions

| Field Name                                | Description                                          |
| ----------------------------------------- | ---------------------------------------------------- |
| REPORT_YEAR / REPORT_MONTH                | Reporting year and month                             |
| RECORD_COUNT                              | Number of accounting records in the month            |
| SELECT / INSERT / UPDATE / DELETE / MERGE | Count of each SQL operation type                     |
| TOTAL_DML                                 | Total DML operations count                           |
| AVG_DAILY_DML                             | Average daily DML operations                         |
| COMMIT_PER_DML                            | Average commits per DML operation                    |
| DELETE_TO_SELECT_RATIO                    | Ratio of DELETE to SELECT operations (%)             |
| LOCK_CONFLICT_RATE                        | Lock conflict rate (deadlock + timeout percentage %) |
| PEAK_DML_COUNT                            | Maximum DML count in a single accounting record      |

---

## 2. DB2 Monthly DML Distribution Report (Accounting)

### Description

This report analyzes the distribution trends and percentage changes of different DML statement types (SELECT, INSERT, UPDATE, DELETE, MERGE) on a monthly basis from accounting data. It includes row-level operation statistics.

### SQL Code

```sql
-- =============================================
-- DB2 Monthly DML Distribution Report (Accounting)
-- Author: Jay Yao
-- Purpose: Analyze monthly DML operation distribution and trends
-- Data Source: DTRBDR55.DB2PMFACCT_GENERAL
-- =============================================

SELECT
    SUBSYSTEM_ID,
    YEAR(TIMESTAMP) AS REPORT_YEAR,                -- Aggregation year
    MONTH(TIMESTAMP) AS REPORT_MONTH,              -- Aggregation month
    COUNT(DISTINCT DATE(TIMESTAMP)) AS ACTIVE_DAYS,-- Days with activity

    SUM(SELECT) AS TOTAL_SELECTS,                  -- Number of SELECT operations
    SUM(INSERT) AS TOTAL_INSERTS,                  -- Number of INSERT operations
    SUM(UPDATE) AS TOTAL_UPDATES,                  -- Number of UPDATE operations
    SUM(DELETE) AS TOTAL_DELETES,                  -- Number of DELETE operations
    SUM(MERGE) AS TOTAL_MERGES,                    -- Number of MERGE operations

    SUM(SELECT + INSERT + UPDATE + DELETE + MERGE) AS TOTAL_DML,  -- Total DML

    -- Percentage distribution
    ROUND(SUM(SELECT) * 100.0 / NULLIF(SUM(SELECT + INSERT + UPDATE + DELETE + MERGE), 0), 2) AS SELECT_PCT,
    ROUND(SUM(INSERT) * 100.0 / NULLIF(SUM(SELECT + INSERT + UPDATE + DELETE + MERGE), 0), 2) AS INSERT_PCT,
    ROUND(SUM(UPDATE) * 100.0 / NULLIF(SUM(SELECT + INSERT + UPDATE + DELETE + MERGE), 0), 2) AS UPDATE_PCT,
    ROUND(SUM(DELETE) * 100.0 / NULLIF(SUM(SELECT + INSERT + UPDATE + DELETE + MERGE), 0), 2) AS DELETE_PCT,
    ROUND(SUM(MERGE) * 100.0 / NULLIF(SUM(SELECT + INSERT + UPDATE + DELETE + MERGE), 0), 2) AS MERGE_PCT,

    -- Write operation ratio (INSERT + UPDATE + DELETE + MERGE)
    ROUND(SUM(INSERT + UPDATE + DELETE + MERGE) * 100.0 / 
          NULLIF(SUM(SELECT + INSERT + UPDATE + DELETE + MERGE), 0), 2) AS WRITE_OPERATION_PCT,

    -- Read-to-Write ratio
    CASE WHEN SUM(INSERT + UPDATE + DELETE + MERGE) > 0 THEN
         ROUND(SUM(SELECT) * 1.0 / SUM(INSERT + UPDATE + DELETE + MERGE), 2)
    ELSE NULL END AS READ_WRITE_RATIO

FROM DTRBDR55.DB2PMFACCT_GENERAL
WHERE 1=1
  AND SUBSYSTEM_ID = 'PDBC'
  AND TIMESTAMP BETWEEN '2025-01-01-00.00.00' AND '2025-12-31-23.59.59'

GROUP BY SUBSYSTEM_ID, YEAR(TIMESTAMP), MONTH(TIMESTAMP)
ORDER BY YEAR(TIMESTAMP) DESC, MONTH(TIMESTAMP) DESC;
```

### Field Descriptions

| Field Name                                                    | Description                                                       |
| ------------------------------------------------------------- | ----------------------------------------------------------------- |
| REPORT_YEAR / REPORT_MONTH                                    | Reporting year and month                                          |
| ACTIVE_DAYS                                                   | Number of days with activity in the month                         |
| TOTAL_SELECTS / INSERTS / UPDATES / DELETES / MERGES          | Total count of each DML operation type                            |
| SELECT_PCT / INSERT_PCT / UPDATE_PCT / DELETE_PCT / MERGE_PCT | Percentage of each DML type (%)                                   |
| WRITE_OPERATION_PCT                                           | Write operation percentage (INSERT + UPDATE + DELETE + MERGE) (%) |
| READ_WRITE_RATIO                                              | Read-to-write ratio (SELECT / write operations)                   |

---

## 3. DB2 Monthly Transaction Summary Report (Accounting)

### Description

This report provides monthly statistics on transaction commits, rollback frequency, and savepoint usage from accounting data. It evaluates monthly system throughput performance trends.

### SQL Code

```sql
-- =============================================
-- DB2 Monthly Transaction Summary Report (Accounting)
-- Author: Jay Yao
-- Purpose: Evaluate monthly DB2 transaction commit/rollback trends
-- Data Source: DTRBDR55.DB2PMFACCT_GENERAL
-- =============================================

SELECT
    SUBSYSTEM_ID,
    YEAR(TIMESTAMP) AS REPORT_YEAR,                -- Aggregation year
    MONTH(TIMESTAMP) AS REPORT_MONTH,              -- Aggregation month
    COUNT(*) AS RECORD_COUNT,                      -- Number of accounting records per month
    COUNT(DISTINCT DATE(TIMESTAMP)) AS ACTIVE_DAYS,

    SUM(COMMIT) AS TOTAL_COMMITS,                  -- Total commits
    SUM(ROLLBACK) AS TOTAL_ROLLBACKS,              -- Total rollbacks
    SUM(SVPT_REQUESTS) AS TOTAL_SAVEPOINTS,        -- Total savepoint requests
    SUM(SVPT_ROLLBACK) AS TOTAL_SVPT_ROLLBACKS,    -- Total savepoint rollbacks

    -- Daily average commits
    ROUND(SUM(COMMIT) * 1.0 / 
          COUNT(DISTINCT DATE(TIMESTAMP)), 2) AS AVG_DAILY_COMMITS,

    -- Commit success ratio
    CASE WHEN SUM(COMMIT + ROLLBACK) > 0 THEN
         ROUND(SUM(COMMIT) * 100.0 /
               SUM(COMMIT + ROLLBACK), 2)
    ELSE NULL END AS COMMIT_SUCCESS_RATIO,         -- % successful commits

    -- Rollback rate trend
    CASE WHEN SUM(COMMIT + ROLLBACK) > 0 THEN
         ROUND(SUM(ROLLBACK) * 100.0 /
               SUM(COMMIT + ROLLBACK), 2)
    ELSE NULL END AS ROLLBACK_RATE,                -- Rollback rate (%)

    -- Savepoint rollback rate
    CASE WHEN SUM(SVPT_REQUESTS) > 0 THEN
         ROUND(SUM(SVPT_ROLLBACK) * 100.0 /
               SUM(SVPT_REQUESTS), 2)
    ELSE NULL END AS SVPT_ROLLBACK_RATE            -- Savepoint rollback rate (%)

FROM DTRBDR55.DB2PMFACCT_GENERAL
WHERE 1=1
  AND SUBSYSTEM_ID = 'PDBC'
  AND TIMESTAMP BETWEEN '2025-01-01-00.00.00' AND '2025-12-31-23.59.59'

GROUP BY SUBSYSTEM_ID, YEAR(TIMESTAMP), MONTH(TIMESTAMP)
ORDER BY YEAR(TIMESTAMP) DESC, MONTH(TIMESTAMP) DESC;
```

### Field Descriptions

| Field Name                        | Description                               |
| --------------------------------- | ----------------------------------------- |
| REPORT_YEAR / REPORT_MONTH        | Reporting year and month                  |
| ACTIVE_DAYS                       | Number of days with activity in the month |
| TOTAL_COMMITS / ROLLBACKS         | Total commits and rollbacks               |
| TOTAL_SAVEPOINTS / SVPT_ROLLBACKS | Total savepoint requests and rollbacks    |
| AVG_DAILY_COMMITS                 | Average daily commit count                |
| COMMIT_SUCCESS_RATIO              | Successful commit rate (%)                |
| ROLLBACK_RATE                     | Rollback rate (%)                         |
| SVPT_ROLLBACK_RATE                | Savepoint rollback rate (%)               |

---

## 4. DB2 Monthly CPU Performance Report

### Description

This report provides comprehensive monthly CPU utilization analysis from accounting data, including Class 1/Class 2 elapsed time, CPU time, zIIP CPU consumption, and CPU breakdown by component (stored procedures, UDFs, triggers, parallel). This is unique to accounting data and essential for capacity planning.

### SQL Code

```sql
-- =============================================
-- DB2 Monthly CPU Performance Report
-- Author: Jay Yao
-- Purpose: Analyze monthly CPU consumption patterns from accounting data
-- Data Source: DTRBDR55.DB2PMFACCT_GENERAL
-- Fix: Cast to DECIMAL(31,0) to prevent integer overflow (SQLCODE -802)
-- Fix: Added COALESCE to handle NULL values that may exclude months
-- =============================================

SELECT
    SUBSYSTEM_ID,
    YEAR(TIMESTAMP) AS REPORT_YEAR,                -- Aggregation year
    MONTH(TIMESTAMP) AS REPORT_MONTH,              -- Aggregation month
    COUNT(*) AS RECORD_COUNT,                      -- Number of accounting records
    COUNT(DISTINCT DATE(TIMESTAMP)) AS ACTIVE_DAYS,

    -- =========================================
    -- Class 1 Metrics (Application-level)
    -- =========================================
    SUM(DECIMAL(COALESCE(CLASS1_ELAPSED, 0), 31, 0)) AS TOTAL_CLASS1_ELAPSED,     -- Total Class 1 elapsed time (microseconds)
    SUM(DECIMAL(COALESCE(CLASS1_CPU_TOTAL, 0), 31, 0)) AS TOTAL_CLASS1_CPU,       -- Total Class 1 CPU time (microseconds)
    SUM(DECIMAL(COALESCE(CLASS1_CPU_NNESTED, 0), 31, 0)) AS TOTAL_CLASS1_CPU_NNESTED,  -- Class 1 Non-nested CPU
    SUM(DECIMAL(COALESCE(CLASS1_CPU_STPROC, 0), 31, 0)) AS TOTAL_CLASS1_CPU_STPROC,    -- Class 1 CPU in Stored Procedures
    SUM(DECIMAL(COALESCE(CLASS1_CPU_UDF, 0), 31, 0)) AS TOTAL_CLASS1_CPU_UDF,          -- Class 1 CPU in UDFs
    SUM(DECIMAL(COALESCE(CLASS1_CPU_PARAL, 0), 31, 0)) AS TOTAL_CLASS1_CPU_PARAL,      -- Class 1 Parallel CPU
    SUM(DECIMAL(COALESCE(CLASS1_IIP_CPU, 0), 31, 0)) AS TOTAL_CLASS1_ZIIP,        -- Total Class 1 zIIP CPU time

    -- =========================================
    -- Class 2 Metrics (In-DB2 time)
    -- =========================================
    SUM(DECIMAL(COALESCE(CLASS2_ELAPSED, 0), 31, 0)) AS TOTAL_CLASS2_ELAPSED,     -- Total Class 2 elapsed time (microseconds)
    SUM(DECIMAL(COALESCE(CLASS2_CPU_TOTAL, 0), 31, 0)) AS TOTAL_CLASS2_CPU,       -- Total Class 2 CPU time (microseconds)
    SUM(DECIMAL(COALESCE(CLASS2_CPU_NNESTED, 0), 31, 0)) AS TOTAL_CLASS2_CPU_NNESTED,  -- Class 2 Non-nested CPU
    SUM(DECIMAL(COALESCE(CLASS2_CPU_STPROC, 0), 31, 0)) AS TOTAL_CLASS2_CPU_STPROC,    -- Class 2 CPU in Stored Procedures
    SUM(DECIMAL(COALESCE(CLASS2_CPU_UDF, 0), 31, 0)) AS TOTAL_CLASS2_CPU_UDF,          -- Class 2 CPU in UDFs
    SUM(DECIMAL(COALESCE(CLASS2_CPU_PARAL, 0), 31, 0)) AS TOTAL_CLASS2_CPU_PARAL,      -- Class 2 Parallel CPU
    SUM(DECIMAL(COALESCE(CLASS2_IIP_CPU, 0), 31, 0)) AS TOTAL_CLASS2_ZIIP,        -- Total Class 2 zIIP CPU time

    -- =========================================
    -- Additional CPU Components
    -- =========================================
    SUM(DECIMAL(COALESCE(CPU_TRIGGER, 0), 31, 0)) AS TOTAL_CPU_TRIGGER,           -- Total CPU in Triggers
    SUM(DECIMAL(COALESCE(CLASS3_CPU_PARAL, 0), 31, 0)) AS TOTAL_CLASS3_CPU_PARAL, -- Class 3 Parallel CPU

    -- =========================================
    -- zIIP Metrics
    -- =========================================
    SUM(DECIMAL(COALESCE(IIPCP_ELIGIBLE, 0), 31, 0)) AS TOTAL_ZIIP_ELIGIBLE,      -- Total zIIP Eligible CPU
    SUM(DECIMAL(COALESCE(IIP_CPU_STPROC, 0), 31, 0)) AS TOTAL_ZIIP_STPROC,        -- zIIP CPU in Stored Procedures

    -- =========================================
    -- Service Units
    -- =========================================
    SUM(DECIMAL(COALESCE(CLASS1_SU_CPU, 0), 31, 0)) AS TOTAL_CLASS1_SU_CPU,       -- Class 1 Service Units for CPU
    SUM(DECIMAL(COALESCE(CLASS2_SU_CPU, 0), 31, 0)) AS TOTAL_CLASS2_SU_CPU,       -- Class 2 Service Units for CPU
    SUM(DECIMAL(COALESCE(CLASS1_SU_IIP_CPU, 0), 31, 0)) AS TOTAL_CLASS1_SU_ZIIP,  -- Class 1 SU zIIP CPU
    SUM(DECIMAL(COALESCE(CLASS2_SU_IIP_CPU, 0), 31, 0)) AS TOTAL_CLASS2_SU_ZIIP,  -- Class 2 SU zIIP CPU

    -- =========================================
    -- CPU Efficiency Ratios
    -- =========================================
    -- CPU Efficiency Ratio (Class 2 CPU / Class 2 Elapsed)
    CASE WHEN SUM(DECIMAL(COALESCE(CLASS2_ELAPSED, 0), 31, 0)) > 0 THEN
         ROUND(SUM(DECIMAL(COALESCE(CLASS2_CPU_TOTAL, 0), 31, 0)) * 100.0 / 
               SUM(DECIMAL(COALESCE(CLASS2_ELAPSED, 0), 31, 0)), 2)
    ELSE NULL END AS CPU_EFFICIENCY_PCT,           -- CPU utilization percentage

    -- zIIP Offload Rate (zIIP CPU / Total CPU including zIIP)
    CASE WHEN SUM(DECIMAL(COALESCE(CLASS2_CPU_TOTAL, 0), 31, 0)) + SUM(DECIMAL(COALESCE(CLASS2_IIP_CPU, 0), 31, 0)) > 0 THEN
         ROUND(SUM(DECIMAL(COALESCE(CLASS2_IIP_CPU, 0), 31, 0)) * 100.0 / 
               (SUM(DECIMAL(COALESCE(CLASS2_CPU_TOTAL, 0), 31, 0)) + SUM(DECIMAL(COALESCE(CLASS2_IIP_CPU, 0), 31, 0))), 2)
    ELSE NULL END AS ZIIP_OFFLOAD_PCT,             -- zIIP offload percentage

    -- zIIP Eligibility Rate
    CASE WHEN SUM(DECIMAL(COALESCE(CLASS2_CPU_TOTAL, 0), 31, 0)) > 0 THEN
         ROUND(SUM(DECIMAL(COALESCE(IIPCP_ELIGIBLE, 0), 31, 0)) * 100.0 / 
               SUM(DECIMAL(COALESCE(CLASS2_CPU_TOTAL, 0), 31, 0)), 2)
    ELSE NULL END AS ZIIP_ELIGIBLE_PCT,            -- zIIP eligibility percentage

    -- Stored Procedure CPU Ratio
    CASE WHEN SUM(DECIMAL(COALESCE(CLASS2_CPU_TOTAL, 0), 31, 0)) > 0 THEN
         ROUND(SUM(DECIMAL(COALESCE(CLASS2_CPU_STPROC, 0), 31, 0)) * 100.0 / 
               SUM(DECIMAL(COALESCE(CLASS2_CPU_TOTAL, 0), 31, 0)), 2)
    ELSE NULL END AS STPROC_CPU_PCT,               -- Stored Procedure CPU percentage

    -- Parallel CPU Ratio
    CASE WHEN SUM(DECIMAL(COALESCE(CLASS2_CPU_TOTAL, 0), 31, 0)) > 0 THEN
         ROUND(SUM(DECIMAL(COALESCE(CLASS2_CPU_PARAL, 0), 31, 0)) * 100.0 / 
               SUM(DECIMAL(COALESCE(CLASS2_CPU_TOTAL, 0), 31, 0)), 2)
    ELSE NULL END AS PARALLEL_CPU_PCT,             -- Parallel CPU percentage

    -- =========================================
    -- Average Metrics per Record
    -- =========================================
    ROUND(AVG(DECIMAL(COALESCE(CLASS2_ELAPSED, 0), 31, 0)), 2) AS AVG_CLASS2_ELAPSED,
    ROUND(AVG(DECIMAL(COALESCE(CLASS2_CPU_TOTAL, 0), 31, 0)), 2) AS AVG_CLASS2_CPU,

    -- =========================================
    -- Class 3 Suspension Time (Wait Time)
    -- =========================================
    SUM(DECIMAL(COALESCE(CLASS3_SUSP_TOTAL, 0), 31, 0)) AS TOTAL_CLASS3_SUSP,   -- Total Class 3 suspension time

    -- Wait Ratio (Class 3 Suspension / Class 2 Elapsed)
    CASE WHEN SUM(DECIMAL(COALESCE(CLASS2_ELAPSED, 0), 31, 0)) > 0 THEN
         ROUND(SUM(DECIMAL(COALESCE(CLASS3_SUSP_TOTAL, 0), 31, 0)) * 100.0 / 
               SUM(DECIMAL(COALESCE(CLASS2_ELAPSED, 0), 31, 0)), 2)
    ELSE NULL END AS WAIT_RATIO_PCT                -- Percentage of time waiting

FROM DTRBDR55.DB2PMFACCT_GENERAL
WHERE 1=1
  AND SUBSYSTEM_ID = 'PDBC'
  AND TIMESTAMP BETWEEN '2025-01-01-00.00.00' AND '2025-12-31-23.59.59'

GROUP BY SUBSYSTEM_ID, YEAR(TIMESTAMP), MONTH(TIMESTAMP)
ORDER BY YEAR(TIMESTAMP) DESC, MONTH(TIMESTAMP) DESC;
```

### Field Descriptions

| Field Name                          | Description                                                 |
| ----------------------------------- | ----------------------------------------------------------- |
| REPORT_YEAR / REPORT_MONTH          | Reporting year and month                                    |
| ACTIVE_DAYS                         | Number of days with activity                                |
| **Class 1 CPU Metrics**             |                                                             |
| TOTAL_CLASS1_ELAPSED                | Total Class 1 elapsed time (microseconds)                   |
| TOTAL_CLASS1_CPU                    | Total Class 1 CPU time (microseconds)                       |
| TOTAL_CLASS1_CPU_NNESTED            | Class 1 Non-nested CPU time                                 |
| TOTAL_CLASS1_CPU_STPROC             | Class 1 CPU time in Stored Procedures                       |
| TOTAL_CLASS1_CPU_UDF                | Class 1 CPU time in UDFs                                    |
| TOTAL_CLASS1_CPU_PARAL              | Class 1 Parallel CPU time                                   |
| TOTAL_CLASS1_ZIIP                   | Total Class 1 zIIP CPU time                                 |
| **Class 2 CPU Metrics**             |                                                             |
| TOTAL_CLASS2_ELAPSED                | Total Class 2 elapsed time (microseconds)                   |
| TOTAL_CLASS2_CPU                    | Total Class 2 CPU time (microseconds)                       |
| TOTAL_CLASS2_CPU_NNESTED            | Class 2 Non-nested CPU time                                 |
| TOTAL_CLASS2_CPU_STPROC             | Class 2 CPU time in Stored Procedures                       |
| TOTAL_CLASS2_CPU_UDF                | Class 2 CPU time in UDFs                                    |
| TOTAL_CLASS2_CPU_PARAL              | Class 2 Parallel CPU time                                   |
| TOTAL_CLASS2_ZIIP                   | Total Class 2 zIIP CPU time                                 |
| **Additional CPU Components**       |                                                             |
| TOTAL_CPU_TRIGGER                   | Total CPU time in Triggers                                  |
| TOTAL_CLASS3_CPU_PARAL              | Class 3 Parallel CPU time                                   |
| **zIIP Metrics**                    |                                                             |
| TOTAL_ZIIP_ELIGIBLE                 | Total zIIP Eligible CPU time                                |
| TOTAL_ZIIP_STPROC                   | zIIP CPU time in Stored Procedures                          |
| **Service Units**                   |                                                             |
| TOTAL_CLASS1_SU_CPU / SU_ZIIP       | Class 1 Service Units for CPU / zIIP                        |
| TOTAL_CLASS2_SU_CPU / SU_ZIIP       | Class 2 Service Units for CPU / zIIP                        |
| **Efficiency Ratios**               |                                                             |
| CPU_EFFICIENCY_PCT                  | CPU utilization efficiency (CPU time / Elapsed time) %      |
| ZIIP_OFFLOAD_PCT                    | zIIP offload percentage (zIIP CPU / Total CPU)              |
| ZIIP_ELIGIBLE_PCT                   | zIIP eligibility percentage                                 |
| STPROC_CPU_PCT                      | Stored Procedure CPU percentage                             |
| PARALLEL_CPU_PCT                    | Parallel CPU percentage                                     |
| **Averages**                        |                                                             |
| AVG_CLASS2_ELAPSED / CPU            | Average Class 2 elapsed and CPU time per record             |
| **Wait Metrics**                    |                                                             |
| TOTAL_CLASS3_SUSP                   | Total Class 3 suspension (wait) time                        |
| WAIT_RATIO_PCT                      | Percentage of elapsed time spent waiting                    |

---

## 5. DB2 Monthly Wait Time Analysis Report

### Description

This report provides detailed analysis of Class 3 suspension times (wait times) by category. It helps identify the primary sources of wait time in the DB2 subsystem.

### SQL Code

```sql
-- =============================================
-- DB2 Monthly Wait Time Analysis Report
-- Author: Jay Yao
-- Purpose: Analyze monthly wait time distribution from accounting data
-- Data Source: DTRBDR55.DB2PMFACCT_GENERAL
-- Fix: Cast to DECIMAL(31,0) to prevent integer overflow (SQLCODE -802)
-- Fix: Added COALESCE to handle NULL values that may exclude months
-- =============================================

SELECT
    SUBSYSTEM_ID,
    YEAR(TIMESTAMP) AS REPORT_YEAR,                -- Aggregation year
    MONTH(TIMESTAMP) AS REPORT_MONTH,              -- Aggregation month
    COUNT(*) AS RECORD_COUNT,                      -- Number of accounting records

    -- Total Class 3 Suspension Time
    SUM(DECIMAL(COALESCE(CLASS3_SUSP_TOTAL, 0), 31, 0)) AS TOTAL_WAIT_TIME,

    -- Wait Time by Category
    SUM(DECIMAL(COALESCE(CLASS3_LOCK_LATCH, 0), 31, 0)) AS LOCK_LATCH_WAIT,     -- Lock/Latch wait time
    SUM(DECIMAL(COALESCE(CLASS3_SYNC_IO, 0), 31, 0)) AS SYNC_IO_WAIT,           -- Synchronous I/O wait time
    SUM(DECIMAL(COALESCE(CLASS3_DB_IO, 0), 31, 0)) AS DB_IO_WAIT,               -- Database I/O wait time
    SUM(DECIMAL(COALESCE(CLASS3_LOG_WRT_IO, 0), 31, 0)) AS LOG_WRITE_WAIT,      -- Log write I/O wait time
    SUM(DECIMAL(COALESCE(CLASS3_PAGE_LATCH, 0), 31, 0)) AS PAGE_LATCH_WAIT,     -- Page latch wait time
    SUM(DECIMAL(COALESCE(CLASS3_GLOBAL_CONT, 0), 31, 0)) AS GLOBAL_CONT_WAIT,   -- Global contention wait time
    SUM(DECIMAL(COALESCE(CLASS3_ARCH_LOG, 0), 31, 0)) AS ARCH_LOG_WAIT,         -- Archive log wait time

    -- Suspension Counts
    SUM(DECIMAL(COALESCE(LOCK_LATCH_SUSP, 0), 31, 0)) AS LOCK_LATCH_SUSP_CNT,   -- Lock/Latch suspension count
    SUM(DECIMAL(COALESCE(SYNC_IO_SUSP, 0), 31, 0)) AS SYNC_IO_SUSP_CNT,         -- Sync I/O suspension count
    SUM(DECIMAL(COALESCE(DB_IO_SUSP, 0), 31, 0)) AS DB_IO_SUSP_CNT,             -- DB I/O suspension count
    SUM(DECIMAL(COALESCE(LOG_WRT_IO_SUSP, 0), 31, 0)) AS LOG_WRITE_SUSP_CNT,    -- Log write suspension count
    SUM(DECIMAL(COALESCE(PAGE_LATCH_SUSP, 0), 31, 0)) AS PAGE_LATCH_SUSP_CNT,   -- Page latch suspension count

    -- Wait Time Distribution (as percentage of total)
    CASE WHEN SUM(DECIMAL(COALESCE(CLASS3_SUSP_TOTAL, 0), 31, 0)) > 0 THEN
         ROUND(SUM(DECIMAL(COALESCE(CLASS3_LOCK_LATCH, 0), 31, 0)) * 100.0 / 
               SUM(DECIMAL(COALESCE(CLASS3_SUSP_TOTAL, 0), 31, 0)), 2)
    ELSE NULL END AS LOCK_LATCH_PCT,

    CASE WHEN SUM(DECIMAL(COALESCE(CLASS3_SUSP_TOTAL, 0), 31, 0)) > 0 THEN
         ROUND(SUM(DECIMAL(COALESCE(CLASS3_SYNC_IO, 0), 31, 0)) * 100.0 / 
               SUM(DECIMAL(COALESCE(CLASS3_SUSP_TOTAL, 0), 31, 0)), 2)
    ELSE NULL END AS SYNC_IO_PCT,

    CASE WHEN SUM(DECIMAL(COALESCE(CLASS3_SUSP_TOTAL, 0), 31, 0)) > 0 THEN
         ROUND(SUM(DECIMAL(COALESCE(CLASS3_DB_IO, 0), 31, 0)) * 100.0 / 
               SUM(DECIMAL(COALESCE(CLASS3_SUSP_TOTAL, 0), 31, 0)), 2)
    ELSE NULL END AS DB_IO_PCT,

    CASE WHEN SUM(DECIMAL(COALESCE(CLASS3_SUSP_TOTAL, 0), 31, 0)) > 0 THEN
         ROUND(SUM(DECIMAL(COALESCE(CLASS3_LOG_WRT_IO, 0), 31, 0)) * 100.0 / 
               SUM(DECIMAL(COALESCE(CLASS3_SUSP_TOTAL, 0), 31, 0)), 2)
    ELSE NULL END AS LOG_WRITE_PCT

FROM DTRBDR55.DB2PMFACCT_GENERAL
WHERE 1=1
  AND SUBSYSTEM_ID = 'PDBC'
  AND TIMESTAMP BETWEEN '2025-01-01-00.00.00' AND '2025-12-31-23.59.59'

GROUP BY SUBSYSTEM_ID, YEAR(TIMESTAMP), MONTH(TIMESTAMP)
ORDER BY YEAR(TIMESTAMP) DESC, MONTH(TIMESTAMP) DESC;
```

### Field Descriptions

| Field Name                                               | Description                        |
| -------------------------------------------------------- | ---------------------------------- |
| REPORT_YEAR / REPORT_MONTH                               | Reporting year and month           |
| TOTAL_WAIT_TIME                                          | Total Class 3 suspension time      |
| LOCK_LATCH_WAIT / SYNC_IO_WAIT / DB_IO_WAIT              | Wait time by category              |
| LOG_WRITE_WAIT / PAGE_LATCH_WAIT / GLOBAL_CONT_WAIT      | Additional wait time categories    |
| *_SUSP_CNT                                               | Suspension counts by category      |
| LOCK_LATCH_PCT / SYNC_IO_PCT / DB_IO_PCT / LOG_WRITE_PCT | Wait time distribution percentages |

---

## 6. DB2 Monthly Lock Contention Report (Accounting)

### Description

This report provides monthly statistics on deadlocks, timeouts, lock escalations, and lock contention from accounting data.

### SQL Code

```sql
-- =============================================
-- DB2 Monthly Lock Contention Report (Accounting)
-- Author: Jay Yao
-- Purpose: Analyze monthly concurrency issues from accounting data
-- Data Source: DTRBDR55.DB2PMFACCT_GENERAL
-- =============================================

SELECT
    SUBSYSTEM_ID,
    YEAR(TIMESTAMP) AS REPORT_YEAR,                -- Aggregation year
    MONTH(TIMESTAMP) AS REPORT_MONTH,              -- Aggregation month
    COUNT(*) AS RECORD_COUNT,                      -- Number of accounting records
    COUNT(DISTINCT DATE(TIMESTAMP)) AS ACTIVE_DAYS,

    SUM(LOCK_REQ) AS TOTAL_LOCK_REQUESTS,          -- Total lock requests
    SUM(UNLOCK_REQ) AS TOTAL_UNLOCK_REQUESTS,      -- Total unlock requests
    SUM(DEADLOCK) AS TOTAL_DEADLOCKS,              -- Total deadlocks
    SUM(TIMEOUT) AS TOTAL_TIMEOUTS,                -- Total timeouts
    SUM(SUSPEND_LOCK) AS LOCK_SUSPENDS,            -- Lock suspensions
    SUM(SUSPEND_IRLM_LATCH) AS IRLM_LATCH_SUSP,    -- IRLM latch suspensions

    -- Lock Escalations
    SUM(LOCK_ESC_SHARED) AS SHARED_ESCALATIONS,    -- Shared lock escalations
    SUM(LOCK_ESC_EXCLUSIVE) AS EXCLUSIVE_ESCALATIONS, -- Exclusive lock escalations
    SUM(MAX_LOCKS_HELD) AS PEAK_LOCKS_HELD,        -- Peak locks held

    -- Daily averages
    ROUND(SUM(LOCK_REQ) * 1.0 / 
          COUNT(DISTINCT DATE(TIMESTAMP)), 2) AS AVG_DAILY_LOCK_REQUESTS,

    ROUND(SUM(DEADLOCK + TIMEOUT) * 1.0 / 
          COUNT(DISTINCT DATE(TIMESTAMP)), 2) AS AVG_DAILY_CONFLICTS,

    -- Ratios
    CASE WHEN SUM(LOCK_REQ) > 0 THEN
         ROUND(SUM(DEADLOCK) * 100.0 / SUM(LOCK_REQ), 4)
    ELSE NULL END AS DEADLOCK_RATIO,               -- Deadlock rate (%)

    CASE WHEN SUM(LOCK_REQ) > 0 THEN
         ROUND(SUM(TIMEOUT) * 100.0 / SUM(LOCK_REQ), 4)
    ELSE NULL END AS TIMEOUT_RATIO,                -- Timeout rate (%)

    CASE WHEN SUM(LOCK_REQ) > 0 THEN
         ROUND(SUM(SUSPEND_LOCK) * 100.0 / SUM(LOCK_REQ), 4)
    ELSE NULL END AS LOCK_SUSPEND_RATIO,           -- Lock suspension rate (%)

    -- Lock Escalation Rate
    CASE WHEN SUM(LOCK_REQ) > 0 THEN
         ROUND(SUM(LOCK_ESC_SHARED + LOCK_ESC_EXCLUSIVE) * 100.0 / SUM(LOCK_REQ), 4)
    ELSE NULL END AS LOCK_ESCALATION_RATE,         -- Lock escalation rate (%)

    -- Overall contention score
    CASE WHEN SUM(LOCK_REQ) > 0 THEN
         ROUND(SUM(DEADLOCK + TIMEOUT + SUSPEND_LOCK) * 100.0 / SUM(LOCK_REQ), 4)
    ELSE NULL END AS OVERALL_CONTENTION_RATE       -- Total contention rate (%)

FROM DTRBDR55.DB2PMFACCT_GENERAL
WHERE 1=1
  AND SUBSYSTEM_ID = 'PDBC'
  AND TIMESTAMP BETWEEN '2025-01-01-00.00.00' AND '2025-12-31-23.59.59'

GROUP BY SUBSYSTEM_ID, YEAR(TIMESTAMP), MONTH(TIMESTAMP)
ORDER BY YEAR(TIMESTAMP) DESC, MONTH(TIMESTAMP) DESC;
```

### Field Descriptions

| Field Name                                 | Description                               |
| ------------------------------------------ | ----------------------------------------- |
| REPORT_YEAR / REPORT_MONTH                 | Reporting year and month                  |
| ACTIVE_DAYS                                | Number of days with activity in the month |
| TOTAL_LOCK_REQUESTS / UNLOCK_REQUESTS      | Total lock and unlock request count       |
| TOTAL_DEADLOCKS / TIMEOUTS                 | Deadlock and timeout counts               |
| LOCK_SUSPENDS / IRLM_LATCH_SUSP            | Lock and IRLM latch suspension counts     |
| SHARED_ESCALATIONS / EXCLUSIVE_ESCALATIONS | Lock escalation counts by type            |
| PEAK_LOCKS_HELD                            | Maximum locks held at any point           |
| AVG_DAILY_LOCK_REQUESTS / CONFLICTS        | Daily averages                            |
| DEADLOCK_RATIO / TIMEOUT_RATIO             | Deadlock and timeout rates (%)            |
| LOCK_ESCALATION_RATE                       | Lock escalation rate (%)                  |
| OVERALL_CONTENTION_RATE                    | Overall lock contention rate (%)          |

---

## 7. DB2 Monthly Row Operations Report

### Description

This report provides monthly statistics on row-level operations (fetched, inserted, updated, deleted rows). This is unique to accounting data and provides insight into actual data volume processed.

### SQL Code

```sql
-- =============================================
-- DB2 Monthly Row Operations Report
-- Author: Jay Yao
-- Purpose: Analyze monthly row-level operations from accounting data
-- Data Source: DTRBDR55.DB2PMFACCT_GENERAL
-- =============================================

SELECT
    SUBSYSTEM_ID,
    YEAR(TIMESTAMP) AS REPORT_YEAR,                -- Aggregation year
    MONTH(TIMESTAMP) AS REPORT_MONTH,              -- Aggregation month
    COUNT(*) AS RECORD_COUNT,                      -- Number of accounting records
    COUNT(DISTINCT DATE(TIMESTAMP)) AS ACTIVE_DAYS,

    -- Row-level Statistics
    SUM(ROWS_FETCHED) AS TOTAL_ROWS_FETCHED,       -- Total rows fetched
    SUM(ROWS_INSERTED) AS TOTAL_ROWS_INSERTED,     -- Total rows inserted
    SUM(ROWS_UPDATED) AS TOTAL_ROWS_UPDATED,       -- Total rows updated
    SUM(ROWS_DELETED) AS TOTAL_ROWS_DELETED,       -- Total rows deleted

    -- Total rows processed
    SUM(ROWS_FETCHED + ROWS_INSERTED + ROWS_UPDATED + ROWS_DELETED) AS TOTAL_ROWS_PROCESSED,

    -- Daily averages
    ROUND(SUM(ROWS_FETCHED) * 1.0 / 
          COUNT(DISTINCT DATE(TIMESTAMP)), 2) AS AVG_DAILY_ROWS_FETCHED,

    -- Average rows per statement
    CASE WHEN SUM(SELECT) > 0 THEN
         ROUND(SUM(ROWS_FETCHED) * 1.0 / SUM(SELECT), 2)
    ELSE NULL END AS AVG_ROWS_PER_SELECT,          -- Average rows per SELECT

    CASE WHEN SUM(INSERT) > 0 THEN
         ROUND(SUM(ROWS_INSERTED) * 1.0 / SUM(INSERT), 2)
    ELSE NULL END AS AVG_ROWS_PER_INSERT,          -- Average rows per INSERT

    CASE WHEN SUM(UPDATE) > 0 THEN
         ROUND(SUM(ROWS_UPDATED) * 1.0 / SUM(UPDATE), 2)
    ELSE NULL END AS AVG_ROWS_PER_UPDATE,          -- Average rows per UPDATE

    CASE WHEN SUM(DELETE) > 0 THEN
         ROUND(SUM(ROWS_DELETED) * 1.0 / SUM(DELETE), 2)
    ELSE NULL END AS AVG_ROWS_PER_DELETE,          -- Average rows per DELETE

    -- Row distribution percentages
    CASE WHEN SUM(ROWS_FETCHED + ROWS_INSERTED + ROWS_UPDATED + ROWS_DELETED) > 0 THEN
         ROUND(SUM(ROWS_FETCHED) * 100.0 / 
               SUM(ROWS_FETCHED + ROWS_INSERTED + ROWS_UPDATED + ROWS_DELETED), 2)
    ELSE NULL END AS FETCH_PCT,

    CASE WHEN SUM(ROWS_FETCHED + ROWS_INSERTED + ROWS_UPDATED + ROWS_DELETED) > 0 THEN
         ROUND(SUM(ROWS_INSERTED + ROWS_UPDATED + ROWS_DELETED) * 100.0 / 
               SUM(ROWS_FETCHED + ROWS_INSERTED + ROWS_UPDATED + ROWS_DELETED), 2)
    ELSE NULL END AS WRITE_PCT

FROM DTRBDR55.DB2PMFACCT_GENERAL
WHERE 1=1
  AND SUBSYSTEM_ID = 'PDBC'
  AND TIMESTAMP BETWEEN '2025-01-01-00.00.00' AND '2025-12-31-23.59.59'

GROUP BY SUBSYSTEM_ID, YEAR(TIMESTAMP), MONTH(TIMESTAMP)
ORDER BY YEAR(TIMESTAMP) DESC, MONTH(TIMESTAMP) DESC;
```

### Field Descriptions

| Field Name                                        | Description                                |
| ------------------------------------------------- | ------------------------------------------ |
| REPORT_YEAR / REPORT_MONTH                        | Reporting year and month                   |
| TOTAL_ROWS_FETCHED / INSERTED / UPDATED / DELETED | Total row counts by operation type         |
| TOTAL_ROWS_PROCESSED                              | Total rows processed across all operations |
| AVG_DAILY_ROWS_FETCHED                            | Average daily rows fetched                 |
| AVG_ROWS_PER_SELECT / INSERT / UPDATE / DELETE    | Average rows per statement by type         |
| FETCH_PCT / WRITE_PCT                             | Read vs Write row distribution percentage  |

---

## 8. DB2 Month-over-Month Activity Change Detection Report

### Description

This report detects activity change trends between months and identifies which months have the most significant activity changes, including CPU and row-level metrics unique to accounting data.

### SQL Code

```sql
-- =============================================
-- DB2 Month-over-Month Activity Change Detection Report
-- Author: Jay Yao
-- Purpose: Detect months with most significant activity changes
-- Data Source: DTRBDR55.DB2PMFACCT_GENERAL
-- =============================================

WITH MONTHLY_STATS AS (
    SELECT
        SUBSYSTEM_ID,
        YEAR(TIMESTAMP) AS REPORT_YEAR,
        MONTH(TIMESTAMP) AS REPORT_MONTH,
      
        SUM(SELECT + INSERT + UPDATE + DELETE + MERGE) AS TOTAL_DML,
        SUM(COMMIT) AS TOTAL_COMMITS,
        SUM(DEADLOCK + TIMEOUT) AS TOTAL_CONFLICTS,
        SUM(LOCK_REQ) AS TOTAL_LOCK_REQUESTS,
        SUM(CLASS2_CPU_TOTAL) AS TOTAL_CPU,
        SUM(ROWS_FETCHED + ROWS_INSERTED + ROWS_UPDATED + ROWS_DELETED) AS TOTAL_ROWS

    FROM DTRBDR55.DB2PMFACCT_GENERAL
    WHERE 1=1
      AND SUBSYSTEM_ID = 'PDBC'
      AND TIMESTAMP BETWEEN '2025-01-01-00.00.00' AND '2025-12-31-23.59.59'

    GROUP BY SUBSYSTEM_ID, YEAR(TIMESTAMP), MONTH(TIMESTAMP)
),
MONTHLY_CHANGES AS (
    SELECT
        CURR.SUBSYSTEM_ID,
        CURR.REPORT_YEAR,
        CURR.REPORT_MONTH,
        CURR.TOTAL_DML,
        PREV.TOTAL_DML AS PREV_DML,
        CURR.TOTAL_COMMITS,
        PREV.TOTAL_COMMITS AS PREV_COMMITS,
        CURR.TOTAL_CONFLICTS,
        PREV.TOTAL_CONFLICTS AS PREV_CONFLICTS,
        CURR.TOTAL_CPU,
        PREV.TOTAL_CPU AS PREV_CPU,
        CURR.TOTAL_ROWS,
        PREV.TOTAL_ROWS AS PREV_ROWS,
      
        -- DML Change Rate (%)
        CASE WHEN PREV.TOTAL_DML > 0 THEN
             ROUND((CURR.TOTAL_DML - PREV.TOTAL_DML) * 100.0 / PREV.TOTAL_DML, 2)
        ELSE NULL END AS DML_CHANGE_PCT,
      
        -- Commit Change Rate (%)
        CASE WHEN PREV.TOTAL_COMMITS > 0 THEN
             ROUND((CURR.TOTAL_COMMITS - PREV.TOTAL_COMMITS) * 100.0 / PREV.TOTAL_COMMITS, 2)
        ELSE NULL END AS COMMIT_CHANGE_PCT,
      
        -- Conflict Change Rate (%)
        CASE WHEN PREV.TOTAL_CONFLICTS > 0 THEN
             ROUND((CURR.TOTAL_CONFLICTS - PREV.TOTAL_CONFLICTS) * 100.0 / PREV.TOTAL_CONFLICTS, 2)
        ELSE NULL END AS CONFLICT_CHANGE_PCT,

        -- CPU Change Rate (%)
        CASE WHEN PREV.TOTAL_CPU > 0 THEN
             ROUND((CURR.TOTAL_CPU - PREV.TOTAL_CPU) * 100.0 / PREV.TOTAL_CPU, 2)
        ELSE NULL END AS CPU_CHANGE_PCT,

        -- Rows Change Rate (%)
        CASE WHEN PREV.TOTAL_ROWS > 0 THEN
             ROUND((CURR.TOTAL_ROWS - PREV.TOTAL_ROWS) * 100.0 / PREV.TOTAL_ROWS, 2)
        ELSE NULL END AS ROWS_CHANGE_PCT,
      
        -- Absolute DML Change
        CURR.TOTAL_DML - COALESCE(PREV.TOTAL_DML, 0) AS DML_DELTA
      
    FROM MONTHLY_STATS CURR
    LEFT JOIN MONTHLY_STATS PREV
        ON CURR.SUBSYSTEM_ID = PREV.SUBSYSTEM_ID
       AND (CURR.REPORT_YEAR * 12 + CURR.REPORT_MONTH) = 
           (PREV.REPORT_YEAR * 12 + PREV.REPORT_MONTH + 1)
)
SELECT
    SUBSYSTEM_ID,
    REPORT_YEAR,
    REPORT_MONTH,
    TOTAL_DML,
    PREV_DML,
    DML_DELTA,
    DML_CHANGE_PCT,
    COMMIT_CHANGE_PCT,
    CONFLICT_CHANGE_PCT,
    CPU_CHANGE_PCT,
    ROWS_CHANGE_PCT,
  
    -- Volatility Score (absolute sum of all change rates)
    ABS(COALESCE(DML_CHANGE_PCT, 0)) + 
    ABS(COALESCE(COMMIT_CHANGE_PCT, 0)) + 
    ABS(COALESCE(CONFLICT_CHANGE_PCT, 0)) +
    ABS(COALESCE(CPU_CHANGE_PCT, 0)) +
    ABS(COALESCE(ROWS_CHANGE_PCT, 0)) AS VOLATILITY_SCORE,
  
    -- Change Direction Indicator
    CASE 
        WHEN DML_CHANGE_PCT > 20 THEN 'SPIKE'
        WHEN DML_CHANGE_PCT > 10 THEN 'UP'
        WHEN DML_CHANGE_PCT < -20 THEN 'DROP'
        WHEN DML_CHANGE_PCT < -10 THEN 'DOWN'
        ELSE 'STABLE'
    END AS TREND_INDICATOR

FROM MONTHLY_CHANGES
ORDER BY VOLATILITY_SCORE DESC NULLS LAST;
```

### Field Descriptions

| Field Name                 | Description                                         |
| -------------------------- | --------------------------------------------------- |
| REPORT_YEAR / REPORT_MONTH | Reporting year and month                            |
| TOTAL_DML / PREV_DML       | Current and previous month DML totals               |
| DML_DELTA                  | Absolute change in DML operations                   |
| DML_CHANGE_PCT             | DML month-over-month change rate (%)                |
| COMMIT_CHANGE_PCT          | Commit month-over-month change rate (%)             |
| CONFLICT_CHANGE_PCT        | Lock conflict month-over-month change rate (%)      |
| CPU_CHANGE_PCT             | CPU time month-over-month change rate (%)           |
| ROWS_CHANGE_PCT            | Row operations month-over-month change rate (%)     |
| VOLATILITY_SCORE           | Volatility score (sum of absolute change rates)     |
| TREND_INDICATOR            | Trend indicator (SPIKE / UP / STABLE / DOWN / DROP) |

---

## 9. DB2 Peak Activity Month Identification Report

### Description

This report identifies peak months for each key metric from accounting data, including CPU and row-level metrics.

### SQL Code

```sql
-- =============================================
-- DB2 Peak Activity Month Identification Report
-- Author: Jay Yao
-- Purpose: Identify months with peak activity across key metrics
-- Data Source: DTRBDR55.DB2PMFACCT_GENERAL
-- =============================================

WITH MONTHLY_STATS AS (
    SELECT
        SUBSYSTEM_ID,
        YEAR(TIMESTAMP) AS REPORT_YEAR,
        MONTH(TIMESTAMP) AS REPORT_MONTH,
      
        SUM(SELECT + INSERT + UPDATE + DELETE + MERGE) AS TOTAL_DML,
        SUM(COMMIT) AS TOTAL_COMMITS,
        SUM(DEADLOCK + TIMEOUT) AS TOTAL_CONFLICTS,
        SUM(LOCK_REQ) AS TOTAL_LOCK_REQUESTS,
        SUM(ROLLBACK) AS TOTAL_ROLLBACKS,
        SUM(CLASS2_CPU_TOTAL) AS TOTAL_CPU,
        SUM(CLASS2_ELAPSED) AS TOTAL_ELAPSED,
        SUM(ROWS_FETCHED) AS TOTAL_ROWS_FETCHED

    FROM DTRBDR55.DB2PMFACCT_GENERAL
    WHERE 1=1
      AND SUBSYSTEM_ID = 'PDBC'
      AND TIMESTAMP BETWEEN '2025-01-01-00.00.00' AND '2025-12-31-23.59.59'

    GROUP BY SUBSYSTEM_ID, YEAR(TIMESTAMP), MONTH(TIMESTAMP)
),
RANKED_STATS AS (
    SELECT
        SUBSYSTEM_ID,
        REPORT_YEAR,
        REPORT_MONTH,
        TOTAL_DML,
        TOTAL_COMMITS,
        TOTAL_CONFLICTS,
        TOTAL_LOCK_REQUESTS,
        TOTAL_ROLLBACKS,
        TOTAL_CPU,
        TOTAL_ELAPSED,
        TOTAL_ROWS_FETCHED,
      
        -- Rank for each metric (1 = highest)
        ROW_NUMBER() OVER (ORDER BY TOTAL_DML DESC) AS DML_RANK,
        ROW_NUMBER() OVER (ORDER BY TOTAL_COMMITS DESC) AS COMMIT_RANK,
        ROW_NUMBER() OVER (ORDER BY TOTAL_CONFLICTS DESC) AS CONFLICT_RANK,
        ROW_NUMBER() OVER (ORDER BY TOTAL_LOCK_REQUESTS DESC) AS LOCK_RANK,
        ROW_NUMBER() OVER (ORDER BY TOTAL_ROLLBACKS DESC) AS ROLLBACK_RANK,
        ROW_NUMBER() OVER (ORDER BY TOTAL_CPU DESC) AS CPU_RANK,
        ROW_NUMBER() OVER (ORDER BY TOTAL_ROWS_FETCHED DESC) AS ROWS_RANK
      
    FROM MONTHLY_STATS
)
SELECT
    SUBSYSTEM_ID,
    REPORT_YEAR,
    REPORT_MONTH,
    TOTAL_DML,
    TOTAL_COMMITS,
    TOTAL_CONFLICTS,
    TOTAL_CPU,
    TOTAL_ROWS_FETCHED,
  
    -- Peak indicators
    CASE WHEN DML_RANK = 1 THEN 'PEAK DML' ELSE '' END AS DML_PEAK,
    CASE WHEN COMMIT_RANK = 1 THEN 'PEAK COMMITS' ELSE '' END AS COMMIT_PEAK,
    CASE WHEN CONFLICT_RANK = 1 THEN 'PEAK CONFLICTS' ELSE '' END AS CONFLICT_PEAK,
    CASE WHEN LOCK_RANK = 1 THEN 'PEAK LOCKS' ELSE '' END AS LOCK_PEAK,
    CASE WHEN ROLLBACK_RANK = 1 THEN 'PEAK ROLLBACKS' ELSE '' END AS ROLLBACK_PEAK,
    CASE WHEN CPU_RANK = 1 THEN 'PEAK CPU' ELSE '' END AS CPU_PEAK,
    CASE WHEN ROWS_RANK = 1 THEN 'PEAK ROWS' ELSE '' END AS ROWS_PEAK,
  
    -- Overall rank (sum of all ranks, lower = more active month)
    DML_RANK + COMMIT_RANK + CONFLICT_RANK + LOCK_RANK + 
    ROLLBACK_RANK + CPU_RANK + ROWS_RANK AS OVERALL_RANK_SUM

FROM RANKED_STATS
ORDER BY OVERALL_RANK_SUM ASC;
```

### Field Descriptions

| Field Name                                           | Description                                        |
| ---------------------------------------------------- | -------------------------------------------------- |
| REPORT_YEAR / REPORT_MONTH                           | Reporting year and month                           |
| TOTAL_DML / COMMITS / CONFLICTS / CPU / ROWS_FETCHED | Monthly totals for each metric                     |
| DML_PEAK / COMMIT_PEAK / CPU_PEAK / ROWS_PEAK        | Whether this is the peak month for that metric     |
| CONFLICT_PEAK / LOCK_PEAK / ROLLBACK_PEAK            | Whether this is the peak month for anomaly metrics |
| OVERALL_RANK_SUM                                     | Combined ranking score (lower = more active month) |

---

## 10. DB2 Monthly zIIP Offload Analysis Report

### Description

This report analyzes monthly zIIP (Integrated Information Processor) CPU offload efficiency. This is unique to accounting data and critical for cost optimization in z/OS environments.

### SQL Code

```sql
-- =============================================
-- DB2 Monthly zIIP Offload Analysis Report
-- Author: Jay Yao
-- Purpose: Analyze monthly zIIP offload efficiency from accounting data
-- Data Source: DTRBDR55.DB2PMFACCT_GENERAL
-- =============================================

SELECT
    SUBSYSTEM_ID,
    YEAR(TIMESTAMP) AS REPORT_YEAR,                -- Aggregation year
    MONTH(TIMESTAMP) AS REPORT_MONTH,              -- Aggregation month
    COUNT(*) AS RECORD_COUNT,                      -- Number of accounting records
    COUNT(DISTINCT DATE(TIMESTAMP)) AS ACTIVE_DAYS,

    -- General Purpose CPU (GP CPU)
    SUM(CLASS1_CPU_TOTAL) AS TOTAL_CLASS1_GP_CPU,  -- Total Class 1 GP CPU
    SUM(CLASS2_CPU_TOTAL) AS TOTAL_CLASS2_GP_CPU,  -- Total Class 2 GP CPU

    -- zIIP CPU
    SUM(CLASS1_IIP_CPU) AS TOTAL_CLASS1_ZIIP,      -- Total Class 1 zIIP CPU
    SUM(CLASS2_IIP_CPU) AS TOTAL_CLASS2_ZIIP,      -- Total Class 2 zIIP CPU

    -- zIIP Eligible CPU
    SUM(IIPCP_ELIGIBLE) AS TOTAL_ZIIP_ELIGIBLE,    -- Total zIIP eligible CPU

    -- Total CPU (GP + zIIP)
    SUM(CLASS2_CPU_TOTAL + CLASS2_IIP_CPU) AS TOTAL_CPU,

    -- zIIP Offload Rate (Class 2)
    CASE WHEN SUM(CLASS2_CPU_TOTAL + CLASS2_IIP_CPU) > 0 THEN
         ROUND(SUM(CLASS2_IIP_CPU) * 100.0 / 
               SUM(CLASS2_CPU_TOTAL + CLASS2_IIP_CPU), 2)
    ELSE NULL END AS CLASS2_ZIIP_OFFLOAD_PCT,      -- zIIP offload percentage

    -- zIIP Utilization Rate (Actual vs Eligible)
    CASE WHEN SUM(IIPCP_ELIGIBLE) > 0 THEN
         ROUND(SUM(CLASS2_IIP_CPU) * 100.0 / SUM(IIPCP_ELIGIBLE), 2)
    ELSE NULL END AS ZIIP_UTILIZATION_PCT,         -- zIIP utilization percentage

    -- Stored Procedure zIIP CPU
    SUM(IIP_CPU_STPROC) AS STPROC_ZIIP_CPU,        -- Stored procedure zIIP CPU

    -- Daily averages
    ROUND(SUM(CLASS2_IIP_CPU) * 1.0 / 
          COUNT(DISTINCT DATE(TIMESTAMP)), 2) AS AVG_DAILY_ZIIP_CPU,

    -- Cost Savings Indicator (higher zIIP = more savings)
    CASE 
        WHEN SUM(CLASS2_CPU_TOTAL + CLASS2_IIP_CPU) > 0 
             AND SUM(CLASS2_IIP_CPU) * 100.0 / SUM(CLASS2_CPU_TOTAL + CLASS2_IIP_CPU) > 50 
        THEN 'HIGH SAVINGS'
        WHEN SUM(CLASS2_CPU_TOTAL + CLASS2_IIP_CPU) > 0 
             AND SUM(CLASS2_IIP_CPU) * 100.0 / SUM(CLASS2_CPU_TOTAL + CLASS2_IIP_CPU) > 25 
        THEN 'MODERATE SAVINGS'
        ELSE 'LOW SAVINGS'
    END AS COST_SAVINGS_INDICATOR

FROM DTRBDR55.DB2PMFACCT_GENERAL
WHERE 1=1
  AND SUBSYSTEM_ID = 'PDBC'
  AND TIMESTAMP BETWEEN '2025-01-01-00.00.00' AND '2025-12-31-23.59.59'

GROUP BY SUBSYSTEM_ID, YEAR(TIMESTAMP), MONTH(TIMESTAMP)
ORDER BY YEAR(TIMESTAMP) DESC, MONTH(TIMESTAMP) DESC;
```

### Field Descriptions

| Field Name                 | Description                               |
| -------------------------- | ----------------------------------------- |
| REPORT_YEAR / REPORT_MONTH | Reporting year and month                  |
| TOTAL_CLASS1/2_GP_CPU      | Total General Purpose CPU time by class   |
| TOTAL_CLASS1/2_ZIIP        | Total zIIP CPU time by class              |
| TOTAL_ZIIP_ELIGIBLE        | Total zIIP eligible CPU time              |
| TOTAL_CPU                  | Total CPU time (GP + zIIP)                |
| CLASS2_ZIIP_OFFLOAD_PCT    | zIIP offload percentage                   |
| ZIIP_UTILIZATION_PCT       | zIIP utilization vs eligible percentage   |
| STPROC_ZIIP_CPU            | Stored procedure zIIP CPU time            |
| AVG_DAILY_ZIIP_CPU         | Average daily zIIP CPU consumption        |
| COST_SAVINGS_INDICATOR     | Cost savings category (HIGH/MODERATE/LOW) |

---

## Usage Notes

### Date Range Parameters

- Modify the `TIMESTAMP BETWEEN` clause to specify the desired year range
- For current year analysis: `'2025-01-01-00.00.00' AND '2025-12-31-23.59.59'`
- For historical comparison: extend the date range to include multiple years

### Subsystem Filter

- Change `SUBSYSTEM_ID = 'PDBC'` to target different DB2 subsystems
- Remove the filter to aggregate across all subsystems

### Key Differences from Statistics Table Reports

| Feature                 | STAT Table   | ACCT Table               |
| ----------------------- | ------------ | ------------------------ |
| Data granularity        | System-level | Thread/Plan-level        |
| CPU metrics             | Limited      | Detailed Class 1/2/3     |
| Wait time breakdown     | Basic        | Comprehensive            |
| Row-level stats         | No           | Yes (ROWS_FETCHED, etc.) |
| zIIP metrics            | No           | Yes                      |
| Stored proc/UDF details | Limited      | Extensive                |

### Best Practices

1. Use accounting reports for **detailed performance analysis** at the application level
2. Use statistics reports for **system-wide trend analysis**
3. Combine both for comprehensive **capacity planning**

---

## Additional Filters

### By Plan Name

```sql
AND PLAN_NAME = 'YOUR_PLAN'
```

### By Connection Type

```sql
AND CONNECT_TYPE = 'CICS'  -- or 'BATCH', 'DDF', etc.
```

### By Primary Authorization ID

```sql
AND PRIMAUTH = 'USER_ID'
```

### Top Resource Consumers

Add `ORDER BY` with specific metrics to identify top consumers:

```sql
ORDER BY TOTAL_CLASS2_CPU DESC
FETCH FIRST 10 ROWS ONLY
```

---
