/**
 * Reports Dashboard - Dynamic Data Loading with Filtering and Sorting
 */

let currentData = null;
let currentSort = { column: null, ascending: true };
let currentFilters = {};

// Initialize
document.addEventListener('DOMContentLoaded', function() {
  feather.replace();
  
  // Add click handlers to report links
  document.querySelectorAll('[data-report]').forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const reportPath = this.getAttribute('data-report');
      loadReport(reportPath);
      
      // Update active state
      document.querySelectorAll('[data-report]').forEach(l => l.classList.remove('active'));
      this.classList.add('active');
    });
  });
});

/**
 * Load report data from JSON file
 */
async function loadReport(reportPath) {
  const contentArea = document.getElementById('report-content');
  
  // Reset sort and filters
  currentSort = { column: null, ascending: true };
  currentFilters = {};
  
  // Show loading state
  contentArea.innerHTML = `
    <div class="text-center py-5">
      <div class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
      <p class="mt-2 text-muted">Loading report...</p>
    </div>
  `;
  
  try {
    const response = await fetch(`data/${reportPath}.json`);
    if (!response.ok) throw new Error('Report not found');
    
    currentData = await response.json();
    renderReport();
  } catch (error) {
    contentArea.innerHTML = `
      <div class="alert alert-danger" role="alert">
        <strong>Error:</strong> Could not load report. ${error.message}
      </div>
    `;
  }
}

/**
 * Render the report with current filters and sort
 */
function renderReport() {
  if (!currentData) return;
  
  const contentArea = document.getElementById('report-content');
  
  // Get filtered and sorted data
  let displayData = filterData(currentData.data);
  displayData = sortData(displayData);
  
  // Calculate highlighting on filtered data
  const highlights = calculateHighlights({ ...currentData, data: displayData });
  
  // Build filter controls
  const filterControls = buildFilterControls();
  
  // Build table header with sort indicators
  const headerCells = currentData.columns.map((col, idx) => {
    const sortable = col.sortable ? 'sortable' : '';
    const sortIcon = getSortIcon(idx);
    return `<th scope="col" class="${sortable}" ${col.sortable ? `onclick="sortByColumn(${idx})"` : ''}>${col.name}${sortIcon}</th>`;
  }).join('');
  
  // Build table rows
  const rows = displayData.map((row, rowIndex) => {
    const cells = row.map((cell, colIndex) => {
      const column = currentData.columns[colIndex];
      const formattedValue = formatValue(cell, column.type);
      const highlightClass = getHighlightClass(colIndex, cell, highlights);
      return `<td class="${highlightClass}">${formattedValue}</td>`;
    }).join('');
    return `<tr>${cells}</tr>`;
  }).join('');
  
  // Render complete report
  contentArea.innerHTML = `
    <div class="pt-3 pb-2 mb-3 border-bottom">
      <h1 class="h2">${currentData.title}</h1>
      <p class="text-muted">${currentData.description}</p>
    </div>
    
    <div class="d-flex flex-wrap align-items-center gap-3 mb-3">
      ${filterControls}
      <div class="ms-auto">
        <span class="badge bg-highlight-max-1 me-1">#1 Max</span>
        <span class="badge bg-highlight-max-2 me-2">#2 Max</span>
        <span class="badge bg-highlight-min-1 me-1">#1 Min</span>
        <span class="badge bg-highlight-min-2">#2 Min</span>
      </div>
    </div>
    
    <div class="table-responsive">
      <table class="table table-striped table-hover table-sm">
        <thead class="table-dark">
          <tr>${headerCells}</tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
      </table>
    </div>
    
    <div class="text-muted small mt-3">
      <span data-feather="info" style="width: 14px; height: 14px;"></span>
      Showing ${displayData.length} of ${currentData.data.length} records
    </div>
  `;
  
  feather.replace();
}

/**
 * Build filter dropdown controls
 */
function buildFilterControls() {
  if (!currentData) return '';
  
  let controls = '';
  
  currentData.columns.forEach((col, idx) => {
    if (!col.filterable) return;
    
    // Get unique values for this column
    const uniqueValues = [...new Set(currentData.data.map(row => row[idx]))].sort((a, b) => a - b);
    
    const options = uniqueValues.map(v => {
      const selected = currentFilters[idx] === v ? 'selected' : '';
      const label = col.name === 'Month' ? v : (col.name === 'Quarter' ? `Q${v}` : v);
      return `<option value="${v}" ${selected}>${label}</option>`;
    }).join('');
    
    controls += `
      <div class="d-flex align-items-center gap-1">
        <label class="form-label mb-0 small">${col.name}:</label>
        <select class="form-select form-select-sm" style="width: auto;" onchange="applyFilter(${idx}, this.value)">
          <option value="">All</option>
          ${options}
        </select>
      </div>
    `;
  });
  
  if (controls) {
    controls += `<button class="btn btn-sm btn-outline-secondary" onclick="clearFilters()">Clear Filters</button>`;
  }
  
  return controls;
}

/**
 * Apply a filter
 */
function applyFilter(columnIndex, value) {
  if (value === '') {
    delete currentFilters[columnIndex];
  } else {
    // Convert to appropriate type
    const col = currentData.columns[columnIndex];
    currentFilters[columnIndex] = col.type === 'int' ? parseInt(value) : value;
  }
  renderReport();
}

/**
 * Clear all filters
 */
function clearFilters() {
  currentFilters = {};
  renderReport();
}

/**
 * Filter data based on current filters
 */
function filterData(data) {
  return data.filter(row => {
    for (const [colIdx, filterValue] of Object.entries(currentFilters)) {
      if (row[parseInt(colIdx)] !== filterValue) return false;
    }
    return true;
  });
}

/**
 * Sort by column
 */
function sortByColumn(columnIndex) {
  if (currentSort.column === columnIndex) {
    currentSort.ascending = !currentSort.ascending;
  } else {
    currentSort.column = columnIndex;
    currentSort.ascending = true;
  }
  renderReport();
}

/**
 * Sort data based on current sort settings
 */
function sortData(data) {
  if (currentSort.column === null) return data;
  
  return [...data].sort((a, b) => {
    const aVal = a[currentSort.column];
    const bVal = b[currentSort.column];
    
    let comparison = 0;
    if (typeof aVal === 'number' && typeof bVal === 'number') {
      comparison = aVal - bVal;
    } else {
      comparison = String(aVal).localeCompare(String(bVal));
    }
    
    return currentSort.ascending ? comparison : -comparison;
  });
}

/**
 * Get sort icon for column header
 */
function getSortIcon(columnIndex) {
  const col = currentData.columns[columnIndex];
  if (!col.sortable) return '';
  
  if (currentSort.column !== columnIndex) {
    return '<span class="sort-arrows"><span class="up">&#9650;</span><span class="down">&#9660;</span></span>';
  }
  return currentSort.ascending 
    ? '<span class="sort-active">&#9650;</span>' 
    : '<span class="sort-active">&#9660;</span>';
}

/**
 * Format value based on column type
 */
function formatValue(value, type) {
  if (value === null || value === undefined) return '-';
  
  switch (type) {
    case 'int':
      return Number(value).toLocaleString('en-US', { maximumFractionDigits: 0 });
    case 'float':
      return Number(value).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    case 'percent':
      return Number(value).toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + '%';
    case 'string':
    default:
      return value;
  }
}

/**
 * Calculate top 2 max and min values for highlighting
 */
function calculateHighlights(data) {
  const highlights = {};
  
  data.columns.forEach((col, colIndex) => {
    if (!col.highlight) return;
    
    const values = data.data
      .map(row => row[colIndex])
      .filter(v => typeof v === 'number');
    
    if (values.length < 2) return;
    
    const sorted = [...values].sort((a, b) => a - b);
    
    highlights[colIndex] = {
      max1: sorted[sorted.length - 1],
      max2: sorted[sorted.length - 2],
      min1: sorted[0],
      min2: sorted[1]
    };
  });
  
  return highlights;
}

/**
 * Get highlight CSS class for a cell
 */
function getHighlightClass(colIndex, value, highlights) {
  const colHighlight = highlights[colIndex];
  if (!colHighlight || typeof value !== 'number') return '';
  
  if (value === colHighlight.max1) return 'highlight-max-1';
  if (value === colHighlight.max2) return 'highlight-max-2';
  if (value === colHighlight.min1) return 'highlight-min-1';
  if (value === colHighlight.min2) return 'highlight-min-2';
  
  return '';
}
